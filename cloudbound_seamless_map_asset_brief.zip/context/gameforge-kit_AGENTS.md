# AGENTS.md — GameForge Kit Character Pipeline

This repository provides a provider-agnostic, deterministic procedural 3D character asset pipeline targeting **Godot 4 (2.5D isometric)** via **Blender Python (`bpy`)** and **glTF 2.0 (`.glb`)**.

## Core Rules for AI Agents
1. **Skills orchestrate; scripts execute**: Never write ad-hoc geometry/rigging logic inline when a script in `scripts/characters/` exists.
2. **Never overwrite base assets**: Base models live in `assets/characters/base/<base_model_id>/`. Variants must write to `assets/characters/generated/<asset_id>/`.
3. **Never claim an asset is ready without running validation**: `validate_character.py` must pass (`passed: true`) before export is considered valid.
4. **Report blockers honestly**: If `blender` or `godot` is not installed, report the missing dependency and exact remediation steps instead of faking outputs.
5. **Preserve conventions**:
   - Blender space: `Z` up, `-Y` forward, `1 unit = 1 meter`, feet at `Z = 0`, `root` bone at `(0, 0, 0)`.
   - glTF/Godot export: `+Y` up, `-Z` forward.
   - Standard 20-bone skeleton (`STANDARD_BONES`) + 4 attachment sockets (`attach_hand_R`, `attach_hand_L`, `attach_back`, `attach_head`).

## Skill Orchestration Order

### 1. 3D Character Pipeline (`skills/characters/`, `scripts/characters/`)
1. `character-planner` (`scripts/characters/planner.py`)
2. `character-generator` (`scripts/characters/generate_character.py`) OR `character-customizer` (`scripts/characters/customize_character.py`)
3. `character-rigger` (`scripts/characters/rig_character.py`)
4. `character-animator` (`scripts/characters/animate_character.py`)
5. `character-validator` (`scripts/characters/validate_character.py`)
6. `character-exporter` (`scripts/characters/export_glb.py`)
7. `character-preview` (`scripts/characters/render_preview.py`)

Full 3D pipeline:
```bash
python3 scripts/characters/run_pipeline.py --config presets/characters/variant_swordsman.json
```

### 2. 2D/2.5D Sprite Atlas Pipeline (`skills/sprites/`, `scripts/sprites/`)
1. `sprite-batch-planner` (`scripts/sprites/batch_planner.py`)
2. `sprite-frame-generator` (`adapters/blender/` or `adapters/ai_image/`)
3. `sprite-frame-normalizer` (`scripts/sprites/frame_normalizer.py`)
4. `sprite-atlas-packer` (`scripts/sprites/atlas_packer.py`)
5. `sprite-atlas-validator` + `sprite-consistency-validator` + `sprite-motion-validator` (`scripts/sprites/validators.py`)
6. `sprite-preview-generator` (`scripts/sprites/preview_generator.py`)
7. `sprite-godot-exporter` (`scripts/sprites/godot_exporter.py`)

Full Sprite batch pipeline (`sprite-batch-orchestrator`):
```bash
python3 scripts/sprites/batch_orchestrator.py --profile profiles/examples/mini-vo-lam.json --character variant_swordsman --animations idle walk --directions down right
```
- Never auto-approve `REVIEW_REQUIRED` motion/AI batches into `assets/sprites/approved/`.
- Never fabricate images when Blender or AI Image API is missing; report the blocker honestly.

### 3. Unified Web Asset Viewer & Godot Verification (`scripts/viewer/`, `scripts/godot_verify.py`)
- Build gallery: `python3 scripts/viewer/build_viewer.py` -> `previews/index.html`
- Serve locally (for GLB WebGL): `python3 scripts/viewer/serve_viewer.py --port 8765`
- Approve after review: `python3 scripts/viewer/approve_asset.py --kind 2d|3d --id <id>`
### 4. External Project Integration (Git Submodule)
When invoked from a consuming game repository, always pass `--project-root`, `--output-dir`, `--work-dir`, and `--exporter`:
```bash
python3 tools/gameforge-kit/scripts/sprites/batch_orchestrator.py \
  --project-root . --profile profiles/character.json --character demo_character \
  --output-dir assets/generated --work-dir .gameforge/work --exporter godot
```
Never write generated assets, reports, or previews inside `tools/gameforge-kit/`. See `docs/EXTERNAL_PROJECT_INTEGRATION.md`.
