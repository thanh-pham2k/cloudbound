---
name: sprite-batch-orchestrator
description: Coordinate the end-to-end sprite atlas batch pipeline with resume, single-frame retry, caching, and quality gates.
---

# Sprite Batch Orchestrator

## Purpose & Trigger
Primary entry point for AI Agents to execute a full sprite batch from a project profile and character ID.

## Input / Output Contract
- **Inputs**: `--profile`, `--character`, optional `--animations`, `--directions`, `--adapter`, `--manifest` (resume), `--retry-frame <task_id>:<idx>`, `--dry-run`.
- **Outputs**: `reports/<batch_id>/final-quality-report.json`, atlases, previews, and Godot `.tres`.

## Preconditions
- Project profile is valid; target `approved/` output does not exist.

## Workflow
```bash
python3 scripts/sprites/batch_orchestrator.py \
  --profile profiles/examples/mini-vo-lam.json \
  --character variant_swordsman \
  --animations idle walk \
  --directions down right
```

## Validation
- `final-quality-report.json` records `overall_status` (`PASS` | `REVIEW_REQUIRED` | `FAIL`) and paths to HTML preview + Godot export.

## Failure Handling
- On adapter blocker (`AdapterBlockerError`), exits `2` with exact remediation instructions.
- Supports `--manifest <path> --retry-frame <task>:<idx>` to regenerate only a failed frame.

## Allowed Scripts
- `scripts/sprites/batch_orchestrator.py`

## Limits & Human Review
- Never auto-promotes `REVIEW_REQUIRED` batches to `assets/sprites/approved/`; human sign-off is required.
