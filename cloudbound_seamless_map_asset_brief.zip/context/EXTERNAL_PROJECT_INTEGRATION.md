# External Project Integration Guide (Git Submodule)

`gameforge-kit` is designed to be consumed as a **pinned Git Submodule** inside external game repositories (Godot, Unity, Web, or custom engines) without copying skills or modifying toolkit internals.

## 1. Git Submodule Lifecycle

### Initial Installation
From your game repository root:
```bash
git submodule add https://github.com/thanh-pham2k/gameforge-kit.git tools/gameforge-kit
git submodule update --init --recursive
git commit -m "chore: add gameforge-kit submodule"
```

### Cloning a Repository That Uses `gameforge-kit`
```bash
git clone --recurse-submodules <your-game-repo-url>
# Or after a regular clone:
git submodule update --init --recursive
```

### Pinning, Updating, and Rolling Back
- **Pin a tested commit:** Git submodules automatically pin the exact commit SHA recorded in your parent repository. Never auto-update the submodule on CI or agent runs.
- **Update to a newer tested version:**
  ```bash
  git -C tools/gameforge-kit fetch origin
  git -C tools/gameforge-kit checkout <tested-commit-or-tag>
  git add tools/gameforge-kit
  git commit -m "chore: bump gameforge-kit to <version>"
  ```
- **Rollback to a previous version:**
  ```bash
  git -C tools/gameforge-kit checkout <previous-commit-sha>
  git add tools/gameforge-kit
  git commit -m "revert: rollback gameforge-kit to <previous-commit-sha>"
  ```
- **Migration guidance:** Check `schemas/` (`character.schema.json`, `sprite_profile.schema.json`, `asset_metadata.schema.json`) and `CHANGELOG`/commit notes before bumping `schema_version` or `generator_version`.

---

## 2. AI Agent Skill Discovery

Do **not** assume every AI coding agent (Codex, Claude Code, Antigravity) automatically discovers nested `SKILL.md` files inside `tools/gameforge-kit/skills/`.

- **Recommended (Universal):** Reference `tools/gameforge-kit/AGENTS.md` and the specific `SKILL.md` paths directly in your consuming repository's root `AGENTS.md` (see `examples/external-project/AGENTS.md`).
- **Agent-native discovery:** If your agent supports `.agents/skills/` or plugin directories, symlink or register `tools/gameforge-kit/skills/` explicitly rather than copying files.

---

## 3. External CLI Contract & Output Isolation

All generated assets, temporary source frames, normalized frames, manifests, validation reports, and web previews stay inside your consuming repository:

```bash
python3 tools/gameforge-kit/scripts/sprites/batch_orchestrator.py \
  --project-root . \
  --profile profiles/character.json \
  --character demo_character \
  --output-dir assets/generated \
  --work-dir .gameforge/work \
  --exporter godot
```

- `--project-root`: Consuming game repository root (default: toolkit root for internal usage).
- `--profile`: Path to project profile JSON (resolved relative to `--project-root`).
- `--output-dir`: Destination for packed atlases and optional engine exports (default: `assets/generated` under `--project-root`).
- `--work-dir`: Destination for temporary frames, manifests, reports, and HTML/GIF previews (default: `.gameforge/work` under `--project-root`).
- `--exporter`: `none` or `godot` (default: `godot`). Use `none` for engine-agnostic PNG/JSON output.

### Safety Rules Enforced by Toolkit
- Paths escaping `--project-root` (e.g. `../outside`) or targeting `tools/gameforge-kit/` are rejected with `UnsafePathError`.
- `approve_asset.py` refuses to approve `PENDING`, `FAILED`, or stale reports, and requires `--human-reviewed --reviewer <name>` for `REVIEW_REQUIRED`.
- Approved assets in `assets/approved/` are never overwritten.

---

## 4. Currently Supported vs Planned Extensions

- **Supported now:**
  - Generic profile inheritance (`defaults.json` → project profile), schema validation, batch planning, Pillow frame normalization, grid atlas packing, structural/consistency/motion validation, GIF/contact-sheet/HTML viewer, non-destructive approval, optional Godot 4 `.tres` export, and 3D character `.blend` → `.glb` pipeline (when Blender is installed).
- **Planned / Not Yet Implemented:**
  - `AIImageAdapter` provider HTTP transport (`NOT_IMPLEMENTED` until credentials/transport are wired).
  - Procedural geometry scripts for `creature` and `environment` asset types (contract defined in `schemas/asset_metadata.schema.json`).
