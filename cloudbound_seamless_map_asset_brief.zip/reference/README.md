# Reference images guide

## `concept/`
Ảnh gốc từ `assets/inbox/` của repo. Bao gồm `image.png` và `image copy 2..7.png` (tổng 8 ảnh). Đây là nhóm ảnh concept/visual reference mà `VISUAL_BIBLE.md` nhắc tới ("supplied six-panel gameplay reference takes priority"). Hãy自动 nhận diện panel nào là six-panel board để làm chuẩn composition/palette; các panel sinh ra khác chỉ để đối chiếu.

## `current_scenes/`
- `scene_01.png` … `scene_06.png`: ảnh chụp runtime thực tế từ Godot (1280×720) của 6 màn hiện tại.
- `comparison_3x2.png`: bảng so sánh 6 màn.
- **Ảnh user gửi trong hội thoại tương ứng với `scene_06.png`** (Cổng Thiên Giới): đĩa sân đá tròn nổi cô lập giữa mây — chính là biểu hiện của lỗi "map tách" cần sửa bằng asset seamless.

## `current_terrain/`
- `large_grass_island.png`, `circular_stone_arena.png`, `small_grass_island.png`, `curved_garden_path.png`, `straight_garden_path.png`, `carved_cloud_medallion.png`: các PNG terrain đang được runtime dùng (`assets/processed/terrain/`). `circular_stone_arena.png` là nguồn của đĩa tròn trong ảnh user.
- `existing_tiles/`: các tile nền/platform/bridge đã có trong `assets/base/environment/` — tham khảo style, naming và kích thước, **nhưng lưu ý**: tài liệu `VISUAL_REBUILD_REPORT.md` đánh giá nhiều tile/edge cũ là `INVALID_FOR_PRODUCTION` (checkerboard, seam). Asset mới phải khắc phục các lỗi đó, không copy nguyên.
