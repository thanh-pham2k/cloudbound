# Yêu cầu gốc của user + Kết quả điều tra map "bị tách"

## 1. Yêu cầu gốc (nguyên văn tiếng Việt)

> Kiểm tra giúp tôi tại sao map không liền mạch mà tách ra như vậy nhỉ, vui lòng cho tôi biết thông tin. Tôi muốn map liền lạch chứ không phải kiểu này. Kiểm tra và cho tôi thông tin -> chưa cần action nhé.

Sau đó user yêu cầu đóng gói prompt + context vào ZIP để giao cho agent khác tạo asset (task hiện tại).

Ảnh user đính kèm: cửa sổ Godot DEBUG của **Scene 06 — Cổng Thiên Giới**, cho thấy một đĩa sân đá tròn nổi cô lập giữa biển mây (cổng phát sáng phía trên, rương vàng, 2 cây hoa đào, HUD "Cổng Thiên Giới đã mở! Hãy bước vào!").

## 2. Kết luận điều tra

Map "tách" **không phải lỗi render/texture**, mà là **thiết kế kiến trúc**: 6 màn riêng + mỗi màn là 1 hòn đảo PNG độc lập.

### Bằng chứng code

| Bạn thấy | Nguyên nhân | Vị trí |
|---|---|---|
| 6 khu vực rời rạc, qua cổng là load màn mới | `next_scene_path` trỏ scene kế; `change_scene_to_file()` sau fade đen 0.22s | `project.godot:15`, `scenes/scene_01_mortal_realm.tscn:15`, `scripts/main.gd:129-139` |
| 6 file scene độc lập | `scene_01..06_*.tscn` | `scenes/` |
| Mỗi map là 1 đảo PNG đơn lẻ | `large_grass_island.png` (646×430, scale 2.35×) cho 01/03; `circular_stone_arena.png` (666×434, scale 1.86×) cho 04/05/06 ← đĩa tròn trong ảnh user; scene 02 = 2 đảo + 1 cầu | `scripts/world/cloud_arena.gd:218-233, 251-275, 295-312, 328-424` |
| Vùng đi lại khép kín trong đảo | `_island_outline` đa giác tay + `clamp_to_arena()` | `cloud_arena.gd:517-536` |
| Camera luôn khoá quanh 1 đảo | lerp camera về `(0,0)`, zoom 0.75 | `scripts/main.gd:76, 112-115` |
| Nền trời như bị cắt thành cụm | parallax gồm sprite rời, không tile/wrap | `cloud_arena.gd:314-325, 438-453` |
| Thanh đen trên/dưới ảnh chụp | viewport 1280×720 + stretch `canvas_items`, cửa sổ không đúng 16:9 | `project.godot:25-27` |
| Tài liệu gọi đây là "handoffs" | QA xác nhận thiết kế 5 lần bàn giao màn | `docs/qa/combat_continuity/QA_REPORT.md:40` |

### Hệ quả

- Không có đường đi nối tiếp giữa các khu; mọi chuyển vùng là teleport/load level.
- Ranh giới đảo → trời tạo cảm giác "cụt/gãy", đúng với từ "không liền mạch" của user.
- Muốn map liền mạch cần **code integration** (gộp world liên tục + nối geometry + bỏ portal load scene) — nhưng trước hết cần **asset terrain seamless** để thay các đảo PNG. Đó là nội dung `01_TASK_BRIEF.md`.

### Ghi chú về trạng thái repo

Trong lúc điều tra, repo có thay đổi từ bên ngoài: commit mới `052bc26` ("Tune player combat speed, skill cooldowns, HP...") và thư mục QA `docs/qa/combat_continuity/` đang in-progress về combat/state continuity. Task đó liên quan **lưu HP/XP/loot qua các màn**, KHÔNG phải nối địa hình. Báo cáo trên dựa trên trạng thái code hiện tại.
