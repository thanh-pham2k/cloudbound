# TASK BRIEF — Seamless Continuous Map Terrain Asset Pack

**Dự án:** Đường Đến Thiên Giới / Cloudbound (Godot 4.7, 2.5D top-down 3/4 view)
**Đề xuất batch ID:** `B09_SEAMLESS_TERRAIN` (mới, không ghi đè B01–B08)
**Vai trò:** Asset agent (Luna / image-asset agent). Không sửa gameplay code, không commit/push.

---

## 1. Bối cảnh / Vì sao có task này

User hiện thấy map bị **"tách ra", không liền mạch**: ảnh chụp là Scene 06 (Cổng Thiên Giới) — một **đĩa sân đá tròn nổi cô lập giữa biển mây**. Kết quả điều tra code (xem `02_DIAGNOSIS_AND_USER_REQUEST.md`):

- Project có **6 scene riêng biệt** (`scenes/scene_01..06_*.tscn`), chuyển nhau bằng portal → fade đen → `change_scene_to_file()`. Không có world liền mạch.
- Mỗi "map" là **một file PNG đảo đơn lẻ** đặt trong scene:
  - `assets/processed/terrain/large_grass_island.png` (646×430, scale 2.35×) cho scene 01/03.
  - `assets/processed/terrain/circular_stone_arena.png` (666×434, scale 1.86×) cho scene 04/05/06 ← đĩa tròn trong ảnh user.
  - Scene 02 = 2 copy đảo + 1 ảnh cầu.
- Vùng đi lại là **đa giác khép kín** vẽ tay khớt ảnh đó; `clamp_to_arena()` giữ player trong đảo. Camera luôn kéo về tâm đảo. Nền trời là các sprite parallax rời rạc, không tile.
- Hệ quả: mọi khu vực đều là "ốc đảo", không có đường đi nối tiếp, và có cảm giác cụt/gãy ở ranh giới.

**User muốn:** "map liền lạch" — một bản đồ **liền mạch, có thể đi xuyên suốt**, không còn kiểu đảo rời rạc.

> Lưu ý cho agent: Việc gộp 6 scene thành 1 world là **code integration** (việc của Hydrogen/orchestrator), KHÔNG phải asset. Nhiệm vụ của bạn là tạo **asset terrain có khả năng tạo mặt đất liên tục** để integration sau đó dùng thay các đảo PNG cô lập.

---

## 2. Mục tiêu asset (deliverables đề xuất)

Tạo một **terrain tile/segment set liền mạch** theo đúng art direction của dự án, cho phép ghép thành mặt đất lớn liên tục (thay vì 1 đảo tròn). Tất cả PNG **RGBA 8-bit**, `snake_case` thường, không dấu tiếng Việt.

### 2.1 Bắt buộc

| ID | Tên file gợi ý | Kích thước | Yêu cầu |
|---|---|---|---|
| T1 | `ground_jade_seamless_01.png`, `ground_jade_seamless_02.png` | 128×128 (hoặc 128×64 iso nếu chọn isometric diamond) | Cỏ jade ấm, **tile seamless 4 cạnh**, biến thiên thấp (tránh checkerboard — lỗi từng làm B01 jade tile bị `INVALID_FOR_PRODUCTION`), không nền trời, không đường viền lặp rõ. |
| T2 | `ground_stone_seamless_01.png` | 128×128 | Sân đá kem / rose-taupe, tile seamless 4 cạnh, gạch đá mềm, không ô vuông lặp lộ liễu. |
| T3 | `ground_path_seamless_01.png` | 128×128 | Đường đá đi bộ nối các khu, tile seamless, khớp palette T1/T2. |
| T4 | `ground_grass_stone_transition_*.png` | 128×128 | Bộ chuyển tiếp cỏ↔đá: `edge_north/south/east/west` + `outer_nw/ne/se/sw` + `inner_nw/ne/se/sw`, tile seamless, theo naming已有 trong `assets/base/environment/ground/`. |
| T5 | `platform_cliff_edge_*.png` | 128×128 (cho phép 256×128) | Đoạn vách đá/mép đảo liên tục: `edge_n/s/e/w`, 4 corner, `underside`. Slate-violet, rêu xanh phủ trên, dày front 32–48px cho 2.5D. Thiết kế để ghép thành **bờ biển dài liên tục**, không phải viền của một đĩa tròn. |
| T6 | `bridge_stone_seamless_*.png` | 128×128 / 256×128 | `entrance`, `middle`, `extension`, `exit` — nối 2 vùng đất cùng độ cao deck. Thay cho ảnh cầu đơn lẻ của scene 02. |

### 2.2 Tùy chọn (chỉ làm nếu có thời gian / orchestrator yêu cầu)

- `bg_sky_tileable.png` — nền trời + dải mây có thể lặp/wrap, để map không bị "cụt" ở hậu cảnh.
- Biến thể mùa/theme cho 6 khu (phàm gian / thang mây / thanh vân ngoại vi / trung tâm / đấu trường boss / cổng thiên giới) nhưng **cùng bộ tile gốc** để đảm bảo liền mạch.

---

## 3. Quy chuẩn kỹ thuật (bắt buộc)

Đọc đầy đủ `context/ASSET_SPEC.md`, `context/VISUAL_BIBLE.md`, `context/gameforge-kit_AGENTS.md`.

- **Định dạng:** PNG RGBA 8-bit/channel. Ngoài silhouette phải `alpha = 0` tuyệt đối (không white/sky bake, không checkerboard).
- **Seamless:** tile phải khớp **4 cạnh** (hoặc 4 cạnh isometric). Bắt buộc xuất **preview xếp 5×5** cho mỗi tile ground/path; không được có seam, checkerboard, hay cụm màu lặp lộ rõ.
- **Kích thước:** ground 128×128 (được phép 128×64 iso); platform/bridge theo bảng §2; prop nếu có bottom-center aligned.
- **Palette (VISUAL_BIBLE §2):**
  - Cỏ/moss: `#6BBF9B` / `#4E9A7A` (ấm, hơi vàng).
  - Đá kem/bridge: `#F5EFE0` / `#E4D8BE`; rose-taupe pavers.
  - Vách đá: slate-violet (xem `assets/processed/terrain/large_grass_island.png`).
  - Trời/cyan: `#7CC6EE` / `#4E8EC4` — **chỉ dùng cho rune, crystal, nước xa, boss**, không dàn trải lên đất.
  - Gold `#E8BE54` chỉ cho cổng/portal/reward.
- **Góc nhìn:** fixed 3/4 top-down 2.5D (không render 3D thật). Mặt trên + độ dày phía trước. Scene 03 là chuẩn composition; Scene 05 dùng paving hướng tâm + 4 cột rune.
- **Style:** hand-painted Chinese mythology, nét ink đậm, silhouette rõ ở gameplay zoom, warm painterly cel-shading.
- **Naming:** `<category>_<asset_name>_<variant>.png`, lowercase ASCII, không dấu.

---

## 4. Output &Pipeline

- **Source:** `assets/source/environment/<...>/`
- **Base/final:** `assets/base/environment/ground/`, `assets/base/environment/platforms/`, `assets/base/environment/bridges/`
- **Preview/QA:** `assets/previews/` (ví dụ `<batch_id>_tileability_5x5.png`, contact sheet).
- **TUYỆT ĐỐI không ghi vào** `tools/gameforge-kit/`. Nếu dùng toolkit CLI, luôn truyền:
  ```bash
  --project-root . --output-dir assets/generated --work-dir .gameforge/work --exporter godot
  ```
- Đọc kỹ `context/gameforge-kit_AGENTS.md` + `context/EXTERNAL_PROJECT_INTEGRATION.md` trước khi chạy lệnh. Không auto-approve batch `REVIEW_REQUIRED`.

---

## 5. Tiêu chuẩn nghiệm thu (Acceptance Criteria)

1. Mọi PNG là RGBA 8-bit, nền trong suốt đúng, tên đúng convention.
2. Mỗi ground/path tile **tile seamless 5×5** không seam/checkerboard; có preview chứng minh.
3. T1/T2/T3 phối màu đúng palette, không đưa cyan vào đất thường.
4. T5 tạo được bờ dài liên tục (ghép thử ít nhất 6 segment thẳng + 2 góc không hở).
5. T6 bridge nối được 2 mảnh ground cùng deck height, không hở khe.
6. Chạy `python3 scripts/tools/validate_assets.py` → báo kết quả thật (exit code, warning, fail).
7. Nếu Blender / Godot / AI image API không khả dụng → **báo blocker rõ ràng + hướng khắc phục**, KHÔNG bịa asset hay giả validation.

---

## 6. Báo cáo handoff (bắt buộc)

- Đường dẫn thực tế từng asset + kích thước + byte size.
- Preview 5×5 tiling + contact sheet.
- Kết quả validator (lệnh, exit code, warning/fail) và lỗi import nếu có.
- Provenance: nguồn ảnh/thư mục, profile dùng, bất kỳ thay đổi palette/scale so với VISUAL_BIBLE.
- Vấn đề chất lượng còn lại + dry-run integration note: asset sẽ được Hydrogen integrate vào `cloud_arena.gd` / `island_surface.gd` như thế nào (chỉ gợi ý, không tự sửa code).

---

## 7. Phạm vi & giới hạn

- Asset-only. Không viết simulated gameplay smoke test / combat playtest (theo `AGENTS.md` gốc).
- Không tự ý đổi gameplay, balance, HP/XP, input, scene flow.
- Không commit/push.
- Nếu sau khi đọc context bạn kết luận hướng đúng là **một ảnh bản đồ lớn duy nhất** thay vì tile set, hãy **dừng lại và hỏi orchestrator** trước khi sản xuất hàng loạt — đừng đoán.
