# Cloudbound — Seamless Map Asset Brief (ZIP manifest)

Gói này chứa **toàn bộ prompt + context** để một agent tạo asset khác có thể hiểu đúng yêu cầu và tạo ra asset map liền mạch cho dự án *Đường Đến Thiên Giới (Cloudbound)*.

## Đọc theo thứ tự này

1. `01_TASK_BRIEF.md` — **QUAN TRỌNG NHẤT**: Prompt/brief gửi cho asset agent. Nêu rõ vấn đề, mục tiêu, asset cần tạo, tiêu chuẩn nghiệm thu, ràng buộc pipeline và cách báo cáo blocker.
2. `02_DIAGNOSIS_AND_USER_REQUEST.md` — Yêu cầu gốc của user (tiếng Việt, nguyên văn) + kết quả điều tra code giải thích **tại sao map bị "tách"** (6 scene riêng + mỗi scene là 1 đảo PNG đơn lẻ).
3. `context/` — Tài liệu quy chuẩn cần đọc:
   - `AGENTS.md`, `AGENT_WORKFLOW.md`, `README.md` — luật dự án & workflow đa agent.
   - `VISUAL_BIBLE.md`, `ASSET_SPEC.md`, `ASSET_CATALOG.md`, `BATCH_PLAN.md`, `INTEGRATION_GUIDE.md`, `VISUAL_REBUILD_REPORT.md`, `PROCESSED_INTEGRATION.md` — art direction, spec kỹ thuật, trạng thái asset hiện tại.
   - `gameforge-kit_AGENTS.md`, `EXTERNAL_PROJECT_INTEGRATION.md`, `SKILL_sprite_batch_orchestrator.md` — luật toolkit `gameforge-kit` (bắt buộc đọc trước khi chạy asset task).
   - `profiles_cloudbound_isometric.json`, `profiles_pickup_orbs.json`, `profiles_wukong_gate_a.json` — profile của dự án.
   - `runtime_contract/` — code runtime định nghĩa cách asset terrain được đặt/xử lý (`cloud_arena.gd`, `island_surface.gd`, `painted_sprite.gd`, `main.gd`, scene mẫu). Agent nên đọc để asset khớp contract khi integrate.
4. `reference/` — Ảnh tham khảo:
   - `concept/` — 8 ảnh concept/gốc trong `assets/inbox/` (trong đó có six-panel visual reference; VISUAL_BIBLE nói reference này được ưu tiên).
   - `current_scenes/` — 6 ảnh chụp runtime hiện tại + comparison sheet (scene 06 chính là màn user chụp: đĩa đá tròn nổi cô lập giữa trời).
   - `current_terrain/` — các PNG terrain đang dùng (`large_grass_island.png`, `circular_stone_arena.png`, path/medallion) + các tile nền/bridge hiện có để đối chiếu style.

## Ghi chú quan trọng

- Đây là gói **chỉ đọc / đầu vào**. Asset agent không được sửa `tools/gameforge-kit/`, không tự commit/push, và phải báo cáo trung thực nếu thiếu dependency (Blender / Godot / AI image API).
- Mục tiêu của user là **map liền mạch (seamless)** — không phải 6 hòn đảo rời rạc nối bằng portal load scene. `01_TASK_BRIEF.md` mô tả asset set được đề xuất để đạt điều đó; nếu orchestrator chọn hướng khác (vd một ảnh bản đồ lớn duy nhất thay vì tile set), agent phải hỏi lại trước khi sản xuất số lượng lớn.
- Kiểm tra asset-only: `python3 scripts/tools/validate_assets.py` + preview xếp 5×5. Không viết/chạy simulated gameplay test (theo `AGENTS.md` gốc).
